// PlanDoSee 취약점 연습용 로컬 DB (SQLite, sql.js — 순수 JS/WASM이라 컴파일러 없이 설치됩니다)
// [VULN-TRAINING] 아래에서 만드는 data.db 파일을 SQLite 브라우저(DB Browser for SQLite 등)로
// 열어서 users 테이블의 password 컬럼이 평문으로 저장되어 있는 걸 직접 확인해보세요 (#17).

const path = require("path");
const fs = require("fs");
const initSqlJs = require("sql.js");

const DB_PATH = path.join(__dirname, "data.db");
let db = null;

const SCHEMA_SQL = `
  create table if not exists users (
    id integer primary key autoincrement,
    email text unique not null,
    -- [VULN #17: 민감 정보 노출] 비밀번호를 해시하지 않고 평문 그대로 저장합니다.
    password text not null,
    created_at text not null default (datetime('now'))
  );

  create table if not exists pds_plans (
    id text primary key,
    title text not null,
    period_start text,
    period_end text,
    priority text not null default 'medium',
    success_criteria text,
    estimated_minutes integer,
    is_active integer not null default 1,
    created_at text not null default (datetime('now')),
    updated_at text not null default (datetime('now')),
    user_id integer not null references users(id)
  );

  create table if not exists pds_todos (
    id text primary key,
    time text,
    title text,
    note text,
    tag_id text,
    done integer not null default 0,
    plan_id text,
    deadline text,
    priority text not null default 'medium',
    estimated_minutes integer,
    failed integer not null default 0,
    daily_status text not null default '{}',
    attachment_url text,
    created_at text not null default (datetime('now')),
    updated_at text not null default (datetime('now')),
    user_id integer not null references users(id)
  );

  create table if not exists pds_tags (
    id text primary key,
    label text not null,
    color text not null,
    text_color text,
    created_at text not null default (datetime('now')),
    user_id integer not null references users(id)
  );

  create table if not exists pds_settings (
    id integer primary key autoincrement,
    user_id integer not null unique references users(id),
    mood text,
    reflection text,
    tomorrow_note text,
    next_plan_note text,
    total_time_ms integer not null default 0,
    updated_at text not null default (datetime('now'))
  );

  create table if not exists pds_execution_logs (
    id text primary key,
    todo_id text not null,
    started_at text,
    ended_at text not null default (datetime('now')),
    actual_minutes integer,
    blocked_reason text,
    created_at text not null default (datetime('now'))
  );
`;

async function initDb() {
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    db = new SQL.Database(fs.readFileSync(DB_PATH));
  } else {
    db = new SQL.Database();
  }
  db.run(SCHEMA_SQL);
  persist();
}

function persist() {
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

function all(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

function get(sql, params = []) {
  return all(sql, params)[0] || null;
}

function run(sql, params = []) {
  db.run(sql, params);
  const lastInsertRowid = get("select last_insert_rowid() as id").id;
  const changes = db.getRowsModified();
  persist();
  return { lastInsertRowid, changes };
}

function columns(table) {
  return all(`pragma table_info(${table})`).map((r) => r.name);
}

module.exports = { initDb, all, get, run, columns };

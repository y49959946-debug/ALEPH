// PlanDoSee 취약점 연습용 로컬 모의 백엔드
// ⚠️ 127.0.0.1(로컬호스트)에만 바인딩합니다. 절대 0.0.0.0이나 공인 IP로 바꿔서 외부에 노출하지 마세요.
//
// 이 서버는 Supabase가 하던 역할(인증 + DB + 파일 저장)을 아주 단순하게 흉내낸 것입니다.
// 실무 코드가 아니라 "취약점 연습용"이라서, 여러 곳에 의도적으로 방어를 빼놓았습니다.
// 각 VULN 주석을 찾아서 README.md와 같이 보세요.

const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const express = require("express");
const multer = require("multer");
const store = require("./db");

const app = express();
const PORT = 4000;
const SITE_ROOT = path.join(__dirname, ".."); // PDS-vuln 폴더 전체를 정적으로 서빙
const UPLOAD_ROOT = path.join(__dirname, "uploads");

app.use(express.json({ limit: "5mb" }));
app.use(express.static(SITE_ROOT));

// ----------------------------------------------------------------------------
// 아주 작은 유틸
// ----------------------------------------------------------------------------
function nowIso() {
  return new Date().toISOString();
}
function newId() {
  return crypto.randomUUID();
}

// [VULN #8/#9: 깨진 인증 + 위조 가능한 세션 토큰]
// 진짜 세션 토큰은 서버만 아는 비밀키로 서명(HMAC/JWT)해서, 클라이언트가 내용을 마음대로
// 바꿀 수 없게 막아야 합니다. 이 토큰은 서명이 전혀 없는 "그냥 base64로 감싼 JSON"이라서,
// 누구나 자기 토큰을 디코딩해서 id/email을 다른 사람 걸로 바꾼 뒤 다시 인코딩하면 그 사람
// 행세를 할 수 있습니다. 게다가 사용자 id가 1,2,3... 순서로 증가하는 예측 가능한 값이라
// 다른 사람 id를 추측하기도 쉽습니다.
//
// 브라우저 콘솔에서 해보세요:
//   const k = Object.keys(localStorage).find(x => x.includes("pds_token"));
//   console.log(JSON.parse(atob(localStorage.getItem(k))));   // 내 id/email 확인
//   localStorage.setItem(k, btoa(JSON.stringify({ id: 1, email: "test1@test.local" })));
//   location.reload();                                        // id:1 계정으로 "로그인"됨
function makeToken(user) {
  return Buffer.from(JSON.stringify({ id: user.id, email: user.email }), "utf8").toString("base64");
}
function decodeAuthHeader(req) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return null;
  try {
    const parsed = JSON.parse(Buffer.from(token, "base64").toString("utf8"));
    if (parsed && typeof parsed.id !== "undefined" && parsed.email) return parsed;
    return null;
  } catch (e) {
    return null;
  }
}
function authRequired(req, res, next) {
  const authUser = decodeAuthHeader(req);
  if (!authUser) return res.status(401).json({ error: { message: "로그인이 필요해요." } });
  req.authUser = authUser; // 서버가 DB로 다시 확인하지 않고 그대로 신뢰합니다 (의도적)
  next();
}

// ----------------------------------------------------------------------------
// 인증 라우트
// ----------------------------------------------------------------------------
app.post("/api/auth/signup", (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: { message: "이메일/비밀번호가 필요해요." } });
  if (String(password).length < 6) {
    return res.status(400).json({ error: { code: "weak_password", message: "비밀번호는 6자 이상으로 입력해주세요." } });
  }
  const existing = store.get("select id from users where email = ?", [email]);
  if (existing) {
    return res.status(409).json({ error: { code: "user_already_exists", message: "이미 가입된 이메일이에요(already registered). 로그인해주세요." } });
  }
  // [VULN #17: 민감 정보 노출] 비밀번호를 해시하지 않고 그대로 저장합니다.
  const info = store.run("insert into users (email, password) values (?, ?)", [email, password]);
  const user = { id: info.lastInsertRowid, email };
  const token = makeToken(user);
  // 이메일 인증 절차 없이 가입 즉시 로그인 처리 (원본은 Supabase 이메일 인증을 거쳤지만,
  // 이 연습용 로컬 서버는 그 단계를 아예 생략합니다 — 이것도 "보안 설정 미흡"의 일종입니다)
  res.json({ data: { user, session: { access_token: token, user } } });
});

app.post("/api/auth/signin", (req, res) => {
  const { email, password } = req.body || {};
  const user = store.get("select * from users where email = ?", [email]);
  // [VULN #8: 깨진 인증 - 계정 열거] "그런 계정 없음"과 "비밀번호 틀림"을 서로 다른 문구로
  // 알려줍니다. 공격자가 이메일 목록을 넣어보면서 어떤 이메일이 실제로 가입되어 있는지
  // 알아낼 수 있습니다(User Enumeration). 원본(PlanDoSee_login.html)은 원래 이 두 경우를
  // 일부러 같은 문구로 통일해뒀었는데, 이 사본에서는 그 방어를 되돌려놨습니다.
  if (!user) return res.status(400).json({ error: { code: "user_not_found", message: "그런 이메일로 가입된 계정이 없어요." } });
  if (user.password !== password) return res.status(400).json({ error: { code: "invalid_password", message: "비밀번호가 올바르지 않아요." } });
  // 로그인 시도 횟수 제한(rate limit)도 전혀 없습니다 — 무차별 대입 공격을 막는 장치가 없습니다.
  const token = makeToken(user);
  res.json({ data: { user: { id: user.id, email: user.email }, session: { access_token: token } } });
});

app.post("/api/auth/signout", (req, res) => {
  res.json({ data: {} });
});

app.get("/api/auth/session", (req, res) => {
  const authUser = decodeAuthHeader(req);
  res.json({ data: { session: authUser ? { user: authUser } : null } });
});

// ----------------------------------------------------------------------------
// 일반 테이블 CRUD (원본의 RLS 정책을 그대로 흉내냅니다 — select/update가 열려있는
// 테이블(pds_plans, pds_todos)과, 계속 소유자로 제한된 테이블(pds_tags, pds_settings)로 나눔)
// ----------------------------------------------------------------------------
const TABLE_CONFIG = {
  pds_plans: { scope: { select: "all", update: "all", delete: "owner", insert: "owner" }, jsonFields: [] },
  // [VULN #6/#7: IDOR / 깨진 접근 제어] select·update에 소유자 제한이 없습니다(scope: "all").
  pds_todos: { scope: { select: "all", update: "all", delete: "owner", insert: "owner" }, jsonFields: ["daily_status"] },
  pds_tags: { scope: { select: "owner", update: "owner", delete: "owner", insert: "owner" }, jsonFields: [] },
  pds_settings: { scope: { select: "owner", update: "owner", delete: "owner", insert: "owner" }, jsonFields: [] },
};

const columnCache = {};
function getColumns(table) {
  if (!columnCache[table]) columnCache[table] = store.columns(table);
  return columnCache[table];
}

function deserializeRow(row, config) {
  if (!row) return row;
  const out = { ...row };
  (config.jsonFields || []).forEach((field) => {
    try { out[field] = JSON.parse(out[field]); } catch (e) { out[field] = {}; }
  });
  return out;
}
function serializeForWrite(obj, config, columns, opts) {
  const keepId = !!(opts && opts.keepId);
  const row = {};
  Object.keys(obj || {}).forEach((key) => {
    if (!columns.includes(key)) return; // 알 수 없는 컬럼은 무시
    if (key === "id" && !keepId) return; // update에서는 PK를 바꿀 수 없게 막음
    row[key] = obj[key];
  });
  (config.jsonFields || []).forEach((field) => {
    if (field in row && typeof row[field] !== "string") row[field] = JSON.stringify(row[field]);
  });
  return row;
}
function applyQueryFilters(req, table, clauses, params) {
  const cols = getColumns(table);
  const filters = [].concat(req.query.filter || []);
  filters.forEach((f) => {
    const parts = String(f).split(":");
    const col = parts[0];
    const op = parts[1];
    const val = parts.slice(2).join(":");
    if (!cols.includes(col)) return;
    if (op === "eq") { clauses.push(`${col} = ?`); params.push(val); }
    else if (op === "neq") { clauses.push(`${col} != ?`); params.push(val); }
    else if (op === "in") {
      const vals = val.split(",").filter(Boolean);
      if (vals.length) { clauses.push(`${col} in (${vals.map(() => "?").join(",")})`); params.push(...vals); }
    }
  });
}

const ORDERABLE_COLUMNS = new Set(["created_at", "updated_at", "ended_at", "id"]);

function registerTableRoutes(table, config) {
  app.get(`/api/${table}`, authRequired, (req, res) => {
    const clauses = [];
    const params = [];
    if (config.scope.select === "owner") { clauses.push("user_id = ?"); params.push(req.authUser.id); }
    applyQueryFilters(req, table, clauses, params);
    let sql = `select * from ${table}`;
    if (clauses.length) sql += ` where ${clauses.join(" and ")}`;
    if (req.query.order) {
      const [col, dir] = String(req.query.order).split(":");
      if (ORDERABLE_COLUMNS.has(col)) sql += ` order by ${col} ${dir === "asc" ? "asc" : "desc"}`;
    }
    const rows = store.all(sql, params).map((r) => deserializeRow(r, config));
    res.json({ data: rows });
  });

  app.post(`/api/${table}`, authRequired, (req, res) => {
    const cols = getColumns(table);
    const items = Array.isArray(req.body) ? req.body : [req.body];
    try {
      const inserted = items.map((item) => {
        // keepId: true → 클라이언트가 todo.id처럼 uuid를 미리 만들어서 보내는 경우 그 값을 존중합니다
        // (안 보내면 서버가 새로 만듭니다). pds_settings는 autoincrement라 항상 서버가 만듭니다.
        const row = serializeForWrite(item, config, cols, { keepId: table !== "pds_settings" });
        if (config.scope.insert === "owner") row.user_id = req.authUser.id; // 클라이언트가 보낸 user_id는 무시하고 항상 토큰 기준
        if (table !== "pds_settings") row.id = row.id || newId();
        row.created_at = row.created_at || nowIso();
        row.updated_at = nowIso();
        const writeCols = Object.keys(row);
        try {
          store.run(`insert into ${table} (${writeCols.join(",")}) values (${writeCols.map(() => "?").join(",")})`, writeCols.map((c) => row[c]));
        } catch (e) {
          if (table === "pds_settings" && /unique/i.test(e.message)) {
            return store.get(`select * from pds_settings where user_id = ?`, [req.authUser.id]);
          }
          throw e;
        }
        const idVal = table === "pds_settings" ? store.get("select last_insert_rowid() as id").id : row.id;
        return store.get(`select * from ${table} where id = ?`, [idVal]);
      });
      res.json({ data: inserted.map((r) => deserializeRow(r, config)) });
    } catch (e) {
      res.status(400).json({ error: { message: e.message } });
    }
  });

  app.patch(`/api/${table}`, authRequired, (req, res) => {
    const cols = getColumns(table);
    const clauses = [];
    const params = [];
    if (config.scope.update === "owner") { clauses.push("user_id = ?"); params.push(req.authUser.id); }
    applyQueryFilters(req, table, clauses, params);
    if (!clauses.length) return res.status(400).json({ error: { message: "필터가 필요해요." } });
    const row = serializeForWrite(req.body, config, cols);
    row.updated_at = nowIso();
    const setCols = Object.keys(row);
    if (!setCols.length) return res.json({ data: [] });
    try {
      store.run(`update ${table} set ${setCols.map((c) => `${c} = ?`).join(", ")} where ${clauses.join(" and ")}`, [...setCols.map((c) => row[c]), ...params]);
      const rows = store.all(`select * from ${table} where ${clauses.join(" and ")}`, params).map((r) => deserializeRow(r, config));
      res.json({ data: rows });
    } catch (e) {
      res.status(400).json({ error: { message: e.message } });
    }
  });

  app.delete(`/api/${table}`, authRequired, (req, res) => {
    const clauses = [];
    const params = [];
    if (config.scope.delete === "owner") { clauses.push("user_id = ?"); params.push(req.authUser.id); }
    applyQueryFilters(req, table, clauses, params);
    if (!clauses.length) return res.status(400).json({ error: { message: "필터가 필요해요." } });
    store.run(`delete from ${table} where ${clauses.join(" and ")}`, params);
    res.json({ data: { deleted: true } });
  });
}

Object.keys(TABLE_CONFIG).forEach((table) => registerTableRoutes(table, TABLE_CONFIG[table]));

// 실행 기록(pds_execution_logs) — 소유권이 todo_id를 통해서만 확인되는 테이블이라 별도 처리
app.get("/api/pds_execution_logs", authRequired, (req, res) => {
  const clauses = [];
  const params = [];
  applyQueryFilters(req, "pds_execution_logs", clauses, params);
  let sql = "select * from pds_execution_logs";
  if (clauses.length) sql += ` where ${clauses.join(" and ")}`;
  sql += " order by ended_at desc";
  res.json({ data: store.all(sql, params) });
});
app.post("/api/pds_execution_logs", authRequired, (req, res) => {
  const row = {
    id: newId(),
    todo_id: req.body.todo_id,
    started_at: req.body.started_at || null,
    ended_at: nowIso(),
    actual_minutes: req.body.actual_minutes || null,
    blocked_reason: req.body.blocked_reason || null,
    created_at: nowIso(),
  };
  store.run(
    "insert into pds_execution_logs (id, todo_id, started_at, ended_at, actual_minutes, blocked_reason, created_at) values (?, ?, ?, ?, ?, ?, ?)",
    [row.id, row.todo_id, row.started_at, row.ended_at, row.actual_minutes, row.blocked_reason, row.created_at]
  );
  res.json({ data: [row] });
});

// ----------------------------------------------------------------------------
// [VULN #1: SQL 인젝션] "서버 검색(고급)" 기능 — 문자열을 그대로 이어붙여 SQL을 실행합니다.
// 게다가 user_id로 걸러내지도 않아서, 인젝션이 아니어도 이미 전체 공개 검색입니다.
// ----------------------------------------------------------------------------
app.post("/api/rpc/pds_search_todos_vuln", authRequired, (req, res) => {
  const keyword = (req.body && req.body.keyword) || "";
  const sql = `select * from pds_todos where title like '%${keyword}%' or note like '%${keyword}%'`;
  try {
    const rows = store.all(sql);
    res.json({ data: rows.map((r) => deserializeRow(r, TABLE_CONFIG.pds_todos)) });
  } catch (e) {
    res.status(400).json({ error: { message: e.message } });
  }
});

// ----------------------------------------------------------------------------
// [VULN #13/#14: 파일 업로드 + 경로 문제] 확장자/크기 검증 없음, 사용자별 폴더 분리 없음,
// 클라이언트가 보낸 파일명을 검증 없이 그대로 디스크 경로에 사용합니다.
// ----------------------------------------------------------------------------
const uploadStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const bucket = req.params.bucket.replace(/[^a-zA-Z0-9_-]/g, "");
    const dir = path.join(UPLOAD_ROOT, bucket);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    // 검증/정규화 없이 그대로 사용 — 파일명에 "../"가 들어있으면 실제로 상위 폴더로 빠져나갈 수 있습니다.
    const requestedName = (req.body && req.body.path) || file.originalname;
    cb(null, requestedName);
  },
});
const upload = multer({ storage: uploadStorage });

app.post("/api/storage/:bucket/upload", authRequired, upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: { message: "파일이 없어요." } });
  res.json({ data: { path: req.file.filename } });
});

app.use("/uploads", express.static(UPLOAD_ROOT)); // 인증 없이 전체 공개 (버킷을 public으로 만든 것과 동일)

// ----------------------------------------------------------------------------
store.initDb().then(() => {
  app.listen(PORT, "127.0.0.1", () => {
    console.log(`PDS 취약점 연습용 로컬 서버: http://localhost:${PORT}/PDS/PlanDoSee_login.html`);
    console.log(`(127.0.0.1에만 바인딩되어 있습니다 — 이 컴퓨터 밖에서는 접근할 수 없어요)`);
  });
}).catch((e) => {
  console.error("DB 초기화 실패:", e);
  process.exit(1);
});

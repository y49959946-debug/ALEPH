// PlanDoSee 취약점 연습용 사본 — 로컬 Node/Express 서버용 클라이언트.
// 원래 있던 supabase-js를 대체합니다. PlanDoSee.html / PlanDoSee_login.html의 나머지 코드는
// 그대로 `supabaseClient.xxx` 형태로 부르기 때문에, 여기서 같은 이름의 뼈대만 흉내냅니다.
// (진짜 보안 로직은 전부 local-server/server.js 쪽에 있습니다 — 이 파일은 그냥 통신 도우미입니다)

const API_BASE = window.location.origin; // 같은 서버가 정적 파일도, API도 같이 서빙합니다 (동일 출처)
const TOKEN_KEY = "pds_token";

function getToken() {
  try { return localStorage.getItem(TOKEN_KEY); } catch (e) { return null; }
}
function setToken(token) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch (e) { /* localStorage를 못 쓰는 환경이면 그냥 무시 */ }
}

async function apiRequest(method, path, { query, body, formData } = {}) {
  let url = API_BASE + path;
  if (query) {
    const qs = new URLSearchParams();
    Object.entries(query).forEach(([key, values]) => {
      [].concat(values).forEach((v) => qs.append(key, v));
    });
    const qsString = qs.toString();
    if (qsString) url += `?${qsString}`;
  }
  const headers = {};
  const token = getToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;
  let fetchBody;
  if (formData) {
    fetchBody = formData; // FormData는 Content-Type을 fetch가 알아서 설정
  } else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    fetchBody = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(url, { method, headers, body: fetchBody });
  } catch (e) {
    return { data: null, error: { message: `로컬 서버(${API_BASE})에 연결할 수 없어요. local-server가 켜져 있는지 확인해주세요.` } };
  }
  let json = null;
  try { json = await res.json(); } catch (e) { /* 응답이 JSON이 아닐 수도 있음 */ }
  if (!res.ok) {
    const error = (json && json.error) || { message: res.statusText || "요청에 실패했어요." };
    return { data: null, error };
  }
  return { data: json ? json.data : null, error: null };
}

// ---- 아주 작은 쿼리 빌더 (from().select()/insert()/update()/delete()/eq()/in()/neq()/order()/maybeSingle()) ----
class QueryBuilder {
  constructor(table) {
    this.table = table;
    this.verb = null; // 'select' | 'insert' | 'update' | 'delete'
    this.payload = undefined;
    this.filters = [];
    this.orderSpec = null;
    this.wantsSingle = false;
    this.wantsReturn = false; // insert/update 뒤에 .select()를 부르면 결과 행을 돌려받고 싶다는 뜻
  }
  select(_cols) {
    if (this.verb === null) this.verb = "select";
    else this.wantsReturn = true; // insert(...).select() / update(...).select()
    return this;
  }
  insert(payload) { this.verb = "insert"; this.payload = payload; return this; }
  update(payload) { this.verb = "update"; this.payload = payload; return this; }
  delete() { this.verb = "delete"; return this; }
  eq(col, val) { this.filters.push(`${col}:eq:${val}`); return this; }
  neq(col, val) { this.filters.push(`${col}:neq:${val}`); return this; }
  in(col, vals) { this.filters.push(`${col}:in:${vals.join(",")}`); return this; }
  order(col, { ascending } = {}) { this.orderSpec = `${col}:${ascending ? "asc" : "desc"}`; return this; }
  maybeSingle() { this.wantsSingle = true; return this; }

  async _run() {
    const query = {};
    if (this.filters.length) query.filter = this.filters;
    if (this.orderSpec) query.order = this.orderSpec;

    let result;
    if (this.verb === "select") {
      result = await apiRequest("GET", `/api/${this.table}`, { query });
    } else if (this.verb === "insert") {
      result = await apiRequest("POST", `/api/${this.table}`, { body: this.payload });
    } else if (this.verb === "update") {
      result = await apiRequest("PATCH", `/api/${this.table}`, { query, body: this.payload });
    } else if (this.verb === "delete") {
      result = await apiRequest("DELETE", `/api/${this.table}`, { query });
    } else {
      result = { data: null, error: { message: "알 수 없는 쿼리예요." } };
    }
    if (this.wantsSingle && Array.isArray(result.data)) {
      result = { ...result, data: result.data[0] || null };
    }
    return result;
  }
  then(resolve, reject) { return this._run().then(resolve, reject); } // await 가능하게 만드는 부분
  catch(reject) { return this._run().catch(reject); }
}

const supabaseClient = {
  from(table) { return new QueryBuilder(table); },

  auth: {
    async signInWithPassword({ email, password }) {
      const { data, error } = await apiRequest("POST", "/api/auth/signin", { body: { email, password } });
      if (error) return { error };
      setToken(data.session.access_token);
      return { data, error: null };
    },
    async signUp({ email, password }) {
      const { data, error } = await apiRequest("POST", "/api/auth/signup", { body: { email, password } });
      if (error) return { data: null, error };
      setToken(data.session.access_token);
      return { data: { user: data.user, session: data.session }, error: null };
    },
    async signOut() {
      setToken(null);
      await apiRequest("POST", "/api/auth/signout", {});
      return { error: null };
    },
    async getSession() {
      if (!getToken()) return { data: { session: null } };
      const { data } = await apiRequest("GET", "/api/auth/session", {});
      return { data: { session: (data && data.session) || null } };
    },
    onAuthStateChange() {
      // 로그아웃 버튼이 직접 location.href로 이동시키기 때문에 여기선 아무것도 안 해도 됩니다.
      return { data: { subscription: { unsubscribe() {} } } };
    },
    async exchangeCodeForSession() {
      // 로컬 서버는 이메일 인증 코드 발급/교환 자체가 없어요 (PlanDoSee_verify.html은 사실상 미사용).
      return { error: { message: "이 로컬 버전은 이메일 인증 코드 교환을 지원하지 않아요." } };
    },
  },

  async rpc(name, args) {
    return apiRequest("POST", `/api/rpc/${name}`, { body: args });
  },

  storage: {
    from(bucket) {
      return {
        async upload(filePath, file, _opts) {
          const formData = new FormData();
          formData.append("path", filePath); // path를 file보다 먼저 append해야 서버가 먼저 읽습니다
          formData.append("file", file);
          const { data, error } = await apiRequest("POST", `/api/storage/${bucket}/upload`, { formData });
          return { data, error };
        },
        getPublicUrl(filePath) {
          return { data: { publicUrl: `${API_BASE}/uploads/${bucket}/${filePath}` } };
        },
      };
    },
  },
};

window.supabaseClient = supabaseClient;

# 별도 서버사이드 데모 (커맨드 인젝션 / SSRF / XXE)

PlanDoSee 사본은 정적 HTML + Supabase(BaaS) 구조라서, 서버가 직접 명령을 실행하거나
XML을 파싱하거나 임의 URL로 요청을 보내는 코드가 원래 없습니다. 그래서 이 3가지 취약점은
PlanDoSee 사본 안에 자연스럽게 넣을 수가 없어서, 여기 별도의 아주 작은 데모 서버로 따로
준비했습니다. **PlanDoSee 사본과는 완전히 별개의 실습 자료입니다.**

## 공통 주의사항

- **절대 인터넷에 노출하지 마세요.** 반드시 `localhost`에서만 실행하고, 포트포워딩/터널링도 하지 마세요.
- 실습이 끝나면 바로 서버를 꺼두세요 (Ctrl+C).
- 커맨드 인젝션 데모는 실제로 로컬 셸 명령을 실행합니다 — 신뢰할 수 없는 네트워크에 연결된
  컴퓨터에서는 실행하지 마세요.

## 1. 커맨드 인젝션 — `command_injection_demo.js`

```
npm init -y
npm install express
node command_injection_demo.js
```

`http://localhost:4001` 에서 "인보이스 파일명"을 입력받아 서버가 그 값을 셸 명령에
그대로 끼워 넣습니다 (`child_process.exec`). 정상 입력 예: `invoice-2026-09`.
공격 페이로드 예: `invoice; ls -la` 또는 `invoice && whoami`.

## 2. SSRF — `ssrf_demo.js`

```
node ssrf_demo.js
```

`http://localhost:4002` 에서 "이미지 URL로 가져오기" 기능처럼, 사용자가 준 URL로
서버가 대신 요청을 보내고 결과를 그대로 보여줍니다. 허용 목록(allowlist) 검증이 없어서
`http://localhost:4001` 같은 내부 서비스나, 클라우드 환경이라면 메타데이터 엔드포인트
(`http://169.254.169.254/...`) 접근을 시도하는 연습에 씁니다.

## 3. XXE — `xxe_demo.py`

Node의 기본 XML 라이브러리들은 외부 엔티티를 기본적으로 해석하지 않아서 XXE 데모로
적합하지 않습니다. 그래서 이 데모만 Python(`lxml`)으로 만들었습니다 — 실무에서도
Java/PHP/Python처럼 XML 파서가 기본값으로 외부 엔티티를 허용하는 언어/라이브러리에서
XXE가 자주 나옵니다.

```
pip install flask lxml --break-system-packages   # 또는 가상환경에서 pip install flask lxml
python xxe_demo.py
```

`http://localhost:4003` 에서 XML을 붙여넣으면 서버가 `resolve_entities=True`로 파싱합니다.
아래 페이로드로 서버의 로컬 파일을 읽어보세요 (데모 서버 기준 `/etc/hostname` 예시):

```xml
<?xml version="1.0"?>
<!DOCTYPE data [<!ENTITY xxe SYSTEM "file:///etc/hostname">]>
<data>&xxe;</data>
```

// [VULN-TRAINING] 커맨드 인젝션 데모 — PlanDoSee 사본과는 별개의 독립 실습 서버입니다.
//
// ⚠️ 반드시 localhost에서만 실행하세요. 인터넷에 노출하지 마세요.
//
// 시나리오: "인보이스 파일명"을 입력받아서, 그 이름으로 더미 인보이스 파일을 만드는
// 기능이라고 가정합니다. 실제로는 사용자 입력을 검증/이스케이프 없이 셸 명령에
// 그대로 끼워 넣습니다 (exec는 셸을 거치기 때문에 ; && | 같은 셸 메타문자가 그대로 동작합니다).
//
// 실행: npm install express && node command_injection_demo.js
// 정상 사용 예: invoiceName=invoice-2026-09
// 공격 페이로드 예:
//   invoice; ls -la
//   invoice && whoami
//   invoice | cat /etc/hostname
//
// 고쳐본다면? execFile(이름, [인자배열])로 바꿔서 셸을 거치지 않게 하거나,
// 화이트리스트 정규식(예: /^[a-zA-Z0-9_-]+$/)으로 입력을 검증하면 됩니다.

const express = require("express");
const { exec } = require("child_process");

const app = express();
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.send(`
    <!doctype html>
    <html lang="ko"><body style="font-family: sans-serif; max-width: 640px; margin: 40px auto;">
      <h1>인보이스 파일 만들기 (커맨드 인젝션 데모)</h1>
      <form method="POST" action="/make-invoice">
        <label>인보이스 파일명: <input name="invoiceName" style="width:300px" placeholder="invoice-2026-09" /></label>
        <button type="submit">생성</button>
      </form>
    </body></html>
  `);
});

app.post("/make-invoice", (req, res) => {
  const invoiceName = req.body.invoiceName || "invoice";

  // [VULN] 사용자 입력을 검증 없이 그대로 셸 명령 문자열에 이어붙입니다.
  const command = `echo "dummy invoice content" > /tmp/${invoiceName}.txt && echo "생성됨: /tmp/${invoiceName}.txt"`;

  exec(command, (error, stdout, stderr) => {
    res.type("text/plain");
    if (error) {
      res.send(`명령 실행 중 오류:\n${stderr || error.message}`);
      return;
    }
    res.send(`실행한 명령:\n${command}\n\n결과:\n${stdout}`);
  });
});

const PORT = 4001;
app.listen(PORT, "127.0.0.1", () => {
  console.log(`커맨드 인젝션 데모: http://localhost:${PORT} (localhost 전용, 절대 외부 노출 금지)`);
});

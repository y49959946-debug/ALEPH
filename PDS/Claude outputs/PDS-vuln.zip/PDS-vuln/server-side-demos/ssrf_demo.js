// [VULN-TRAINING] SSRF(서버 사이드 요청 위조) 데모 — PlanDoSee 사본과는 별개의 독립 실습 서버입니다.
//
// ⚠️ 반드시 localhost에서만 실행하세요. 인터넷에 노출하지 마세요.
//
// 시나리오: "이 URL의 이미지를 미리보기로 가져오기" 같은 기능이라고 가정합니다.
// 실제로는 허용 목록(allowlist)/사설 IP 차단 없이, 사용자가 준 URL로 서버가
// 그대로 요청을 대신 보내고 응답을 돌려줍니다.
//
// 실행: npm install express && node ssrf_demo.js  (Node 18+ 는 fetch 내장)
//
// 시도해볼 것:
//   - http://localhost:4001  (커맨드 인젝션 데모가 켜져 있다면 그 화면이 그대로 보임 → 내부 서비스 접근 확인)
//   - http://127.0.0.1:4002/internal-secret  (이 데모 서버 자신의 "내부 전용" 엔드포인트)
//   - 클라우드 환경이라면 http://169.254.169.254/latest/meta-data/ (메타데이터 엔드포인트) 시도
//
// 고쳐본다면? 목적지 호스트를 허용 목록으로 제한하고, 사설/루프백 IP 대역(127.0.0.0/8,
// 10.0.0.0/8, 169.254.0.0/16 등)으로 가는 요청은 무조건 차단하면 됩니다.

const express = require("express");

const app = express();
app.use(express.urlencoded({ extended: true }));

app.get("/internal-secret", (req, res) => {
  res.type("text/plain").send("이 엔드포인트는 '내부망 전용'이라고 가정한 자원입니다. SSRF로만 접근 가능해야 정상입니다.");
});

app.get("/", (req, res) => {
  res.send(`
    <!doctype html>
    <html lang="ko"><body style="font-family: sans-serif; max-width: 640px; margin: 40px auto;">
      <h1>이미지 URL 미리보기 (SSRF 데모)</h1>
      <form method="POST" action="/fetch-url">
        <label>URL: <input name="url" style="width:400px" placeholder="http://127.0.0.1:4002/internal-secret" /></label>
        <button type="submit">가져오기</button>
      </form>
    </body></html>
  `);
});

app.post("/fetch-url", async (req, res) => {
  const target = req.body.url;
  if (!target) return res.status(400).send("url이 필요해요.");

  try {
    // [VULN] 목적지 검증(allowlist, 사설 IP 차단) 없이 서버가 그대로 요청을 대신 보냅니다.
    const response = await fetch(target);
    const text = await response.text();
    res.type("text/plain").send(`요청한 URL: ${target}\n상태 코드: ${response.status}\n\n응답 본문:\n${text.slice(0, 2000)}`);
  } catch (err) {
    res.status(500).type("text/plain").send(`요청 실패: ${err.message}`);
  }
});

const PORT = 4002;
app.listen(PORT, "127.0.0.1", () => {
  console.log(`SSRF 데모: http://localhost:${PORT} (localhost 전용, 절대 외부 노출 금지)`);
});

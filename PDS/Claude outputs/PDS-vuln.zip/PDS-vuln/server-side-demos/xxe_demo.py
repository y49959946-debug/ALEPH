# [VULN-TRAINING] XXE(XML External Entity) 데모 — PlanDoSee 사본과는 별개의 독립 실습 서버입니다.
#
# 반드시 localhost에서만 실행하세요. 인터넷에 노출하지 마세요.
#
# 시나리오: "조직도를 XML로 가져오기" 같은 기능이라고 가정합니다.
# lxml.etree를 resolve_entities=True로(+ DTD 로딩 허용) 설정해서, 외부 엔티티 선언을
# 그대로 해석해버립니다. 이게 바로 고전적인 XXE 취약점 패턴입니다.
#
# 실행: pip install flask lxml --break-system-packages
#       python xxe_demo.py
#
# 시도해볼 페이로드 (서버의 /etc/hostname 파일을 읽어옵니다):
#   <?xml version="1.0"?>
#   <!DOCTYPE data [<!ENTITY xxe SYSTEM "file:///etc/hostname">]>
#   <data>&xxe;</data>
#
# 고쳐본다면? lxml.etree.XMLParser(resolve_entities=False, no_network=True, dtd_validation=False)
# 처럼 외부 엔티티 해석을 꺼두면 됩니다 (Python 표준 defusedxml 라이브러리를 쓰는 것도 방법).

from flask import Flask, request
from lxml import etree

app = Flask(__name__)

PAGE = """
<!doctype html>
<html lang="ko"><body style="font-family: sans-serif; max-width: 640px; margin: 40px auto;">
  <h1>조직도 XML 가져오기 (XXE 데모)</h1>
  <form method="POST" action="/import">
    <textarea name="xml" rows="10" style="width:100%%" placeholder="&lt;data&gt;...&lt;/data&gt;"></textarea><br/>
    <button type="submit">가져오기</button>
  </form>
  <pre>%s</pre>
</body></html>
"""


@app.route("/", methods=["GET"])
def index():
    return PAGE % ""


@app.route("/import", methods=["POST"])
def import_xml():
    xml_text = request.form.get("xml", "")
    try:
        # [VULN] 외부 엔티티 해석을 켜둔 채로 신뢰할 수 없는 XML을 파싱합니다.
        parser = etree.XMLParser(resolve_entities=True, no_network=False)
        root = etree.fromstring(xml_text.encode("utf-8"), parser=parser)
        result = etree.tostring(root, pretty_print=True).decode("utf-8")
    except Exception as e:
        result = f"파싱 실패: {e}"
    return PAGE % result


if __name__ == "__main__":
    print("XXE 데모: http://localhost:4003 (localhost 전용, 절대 외부 노출 금지)")
    app.run(host="127.0.0.1", port=4003)
